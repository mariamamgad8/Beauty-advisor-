// User types
export interface User {
  id: string
  email: string
  name: string
  username: string
  age: number
  gender: "female" | "male" | "other"
  avatarUrl?: string
  hasUploadedPhoto: boolean
  createdAt: string
}

// Auth types
export interface SignUpData {
  name: string
  email: string
  username: string
  password: string
  age: number
  gender: "female" | "male" | "other"
}

export interface LoginData {
  email: string
  password: string
}

// Photo types
export interface Photo {
  id: string
  userId: string
  filePath: string
  publicUrl: string
  uploadedAt: string
  isPrimary: boolean
  fileType?: string
  fileSize?: number
}

// Event types
export type EventType = "formal" | "casual" | "professional" | "party" | "date" | "other"

export interface EventOption {
  id: EventType
  name: string
  description: string
  icon: string
}

// Recommendation types
export interface RecommendationSession {
  id: string
  userId: string
  eventType: EventType
  status: "processing" | "completed"
  createdAt: string
  completedAt?: string
  photoId?: string
}

export interface RecommendationItem {
  title: string
  description: string
  items: string[]
}

export interface Recommendation {
  id: string
  sessionId: string
  makeup: RecommendationItem
  hair: RecommendationItem
  createdAt: string
}

// Feedback types
export interface Feedback {
  id: string
  sessionId: string
  userId: string
  rating: "positive" | "negative"
  comment?: string
  createdAt: string
}

export interface FeedbackData {
  sessionId: string
  rating: "positive" | "negative"
  comment?: string
}
