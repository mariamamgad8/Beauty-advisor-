import type React from "react"
import { AuthProvider } from "@/contexts/auth-context"
import "./globals.css"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <title>Beauty Advisor - Your Personal Style Companion</title>
        <meta
          name="description"
          content="Get personalized makeup and hairstyle recommendations based on your unique features and occasion"
        />
      </head>
      <body>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  )
}

export const metadata = {
      generator: 'v0.dev'
    };
