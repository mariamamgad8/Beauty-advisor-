"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import ProtectedLayout from "@/components/protected-layout"
import { useAuth } from "@/contexts/auth-context"
import { getRecommendationHistory } from "@/services/recommendations"
import { logout } from "@/services/auth"
import type { RecommendationSession } from "@/types"

export default function Dashboard() {
  const router = useRouter()
  const { user, clearAuth } = useAuth()
  const [activeTab, setActiveTab] = useState("history")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [history, setHistory] = useState<RecommendationSession[]>([])

  useEffect(() => {
    // Fetch recommendation history
    async function fetchHistory() {
      try {
        setLoading(true)
        setError("")

        const data = await getRecommendationHistory()
        setHistory(data)
      } catch (err: any) {
        console.error("Error fetching recommendation history:", err)
        setError(err.message || "Failed to load recommendation history")
      } finally {
        setLoading(false)
      }
    }

    fetchHistory()
  }, [])

  const handleLogout = async () => {
    try {
      await logout()
      clearAuth()
      router.push("/")
    } catch (err) {
      console.error("Error during logout:", err)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <ProtectedLayout>
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-pink-800">Welcome, {user?.name || "User"}</h1>
            <p className="text-gray-600">Manage your beauty recommendations and profile</p>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={() => router.push("/select-event")}
              className="border border-pink-600 text-pink-600 hover:bg-pink-50 px-4 py-2 rounded-md"
            >
              New Recommendation
            </button>

            <button
              onClick={handleLogout}
              className="text-gray-600 hover:text-pink-800 hover:bg-pink-100 px-4 py-2 rounded-md"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2 inline"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                />
              </svg>
              Logout
            </button>
          </div>
        </div>

        {error && <div className="mb-4 p-2 bg-red-50 border border-red-200 rounded text-red-600 text-sm">{error}</div>}

        <div className="mb-8">
          <div className="flex border-b border-gray-200">
            <button
              className={`py-2 px-4 font-medium ${
                activeTab === "history"
                  ? "text-pink-600 border-b-2 border-pink-600"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setActiveTab("history")}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2 inline"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              Recommendation History
            </button>
            <button
              className={`py-2 px-4 font-medium ${
                activeTab === "profile"
                  ? "text-pink-600 border-b-2 border-pink-600"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setActiveTab("profile")}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2 inline"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                />
              </svg>
              My Profile
            </button>
          </div>

          {activeTab === "history" && (
            <div className="mt-4">
              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-pink-600"></div>
                </div>
              ) : history.length === 0 ? (
                <div className="bg-white p-6 text-center border rounded-lg shadow-sm">
                  <p className="text-gray-600 mb-4">You haven't received any recommendations yet.</p>
                  <button
                    onClick={() => router.push("/select-event")}
                    className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-md"
                  >
                    Get Your First Recommendation
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {history.map((session) => (
                    <div key={session.id} className="bg-white p-4 rounded-lg border shadow-sm">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="font-semibold text-lg text-pink-800 capitalize">{session.eventType} Event</h3>
                        <span className="text-sm text-gray-500">{formatDate(session.createdAt)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600 capitalize">
                          Status: <span className="font-medium">{session.status}</span>
                        </span>
                        <button
                          onClick={() => router.push(`/recommendations?session=${session.id}`)}
                          className="text-pink-600 hover:text-pink-800"
                        >
                          View Recommendations
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "profile" && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-sm border md:col-span-1">
                <h3 className="text-lg font-semibold text-pink-800 mb-4">Profile Photo</h3>
                <div className="flex flex-col items-center">
                  {user?.avatarUrl ? (
                    <div className="w-32 h-32 rounded-full overflow-hidden mb-4">
                      <img
                        src={user.avatarUrl || "/placeholder.svg"}
                        alt="Profile"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="w-32 h-32 bg-pink-100 rounded-full flex items-center justify-center mb-4">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-12 w-12 text-pink-600"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                        />
                      </svg>
                    </div>
                  )}

                  <button
                    onClick={() => router.push("/upload-photo")}
                    className="mt-2 border border-pink-600 text-pink-600 hover:bg-pink-50 px-3 py-1 rounded-md text-sm"
                  >
                    Update Photo
                  </button>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm border md:col-span-2">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold text-pink-800">Personal Information</h3>
                  <button
                    className="text-pink-600 hover:bg-pink-50 px-3 py-1 rounded-md text-sm"
                    onClick={() => alert("Edit functionality would be implemented here")}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1 inline"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                      />
                    </svg>
                    Edit
                  </button>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Name</h4>
                    <p>{user?.name || "Not provided"}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Username</h4>
                    <p>{user?.username || "Not provided"}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Email</h4>
                    <p>{user?.email || "Not provided"}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Age</h4>
                      <p>{user?.age || "Not provided"}</p>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Gender</h4>
                      <p className="capitalize">{user?.gender || "Not provided"}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm border md:col-span-3">
                <h3 className="text-lg font-semibold text-pink-800 mb-4">Account Settings</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium">Change Password</h4>
                      <p className="text-sm text-gray-500">Update your account password</p>
                    </div>
                    <button
                      className="border border-pink-600 text-pink-600 hover:bg-pink-50 px-3 py-1 rounded-md text-sm"
                      onClick={() => alert("Change password functionality would be implemented here")}
                    >
                      Change
                    </button>
                  </div>

                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium">Notification Preferences</h4>
                      <p className="text-sm text-gray-500">Manage your email notifications</p>
                    </div>
                    <button
                      className="border border-pink-600 text-pink-600 hover:bg-pink-50 px-3 py-1 rounded-md text-sm"
                      onClick={() => alert("Notification preferences would be implemented here")}
                    >
                      Manage
                    </button>
                  </div>

                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-medium text-red-600">Delete Account</h4>
                      <p className="text-sm text-gray-500">Permanently delete your account and all data</p>
                    </div>
                    <button
                      className="border border-red-600 text-red-600 hover:bg-red-50 px-3 py-1 rounded-md text-sm"
                      onClick={() => alert("Delete account functionality would be implemented here")}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </ProtectedLayout>
  )
}
