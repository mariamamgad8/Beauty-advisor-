"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import ProtectedLayout from "@/components/protected-layout"
import { createRecommendationSession } from "@/services/recommendations"
import type { EventOption, EventType } from "@/types"

const eventTypes: EventOption[] = [
  {
    id: "formal",
    name: "Formal Event",
    description: "Weddings, galas, black-tie events",
    icon: "🎭",
  },
  {
    id: "casual",
    name: "Casual Outing",
    description: "Day-to-day activities, coffee dates, shopping",
    icon: "☕",
  },
  {
    id: "professional",
    name: "Professional Setting",
    description: "Job interviews, work meetings, conferences",
    icon: "💼",
  },
  {
    id: "party",
    name: "Party",
    description: "Birthdays, nightclubs, celebrations",
    icon: "🎉",
  },
  {
    id: "date",
    name: "Romantic Date",
    description: "Dinner dates, special occasions with partner",
    icon: "❤️",
  },
  {
    id: "other",
    name: "Other",
    description: "Custom event or occasion",
    icon: "✨",
  },
]

export default function SelectEvent() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [selectedEvent, setSelectedEvent] = useState<EventType | null>(null)
  const [error, setError] = useState("")

  const handleEventSelect = (eventId: EventType) => {
    setSelectedEvent(eventId)
  }

  const handleContinue = async () => {
    if (!selectedEvent) return

    try {
      setLoading(true)
      setError("")

      // Create a new recommendation session
      const session = await createRecommendationSession(selectedEvent)

      // Redirect to recommendations page with session ID
      router.push(`/recommendations?session=${session.id}`)
    } catch (err: any) {
      console.error("Error creating recommendation session:", err)
      setError(err.message || "Failed to create recommendation session")
    } finally {
      setLoading(false)
    }
  }

  return (
    <ProtectedLayout>
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-pink-800">What are you getting ready for?</h2>
          <p className="mt-2 text-gray-600">
            Select the type of event to get personalized makeup and hairstyle recommendations
          </p>
        </div>

        {error && <div className="mb-4 p-2 bg-red-50 border border-red-200 rounded text-red-600 text-sm">{error}</div>}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {eventTypes.map((event) => (
            <div
              key={event.id}
              className={`cursor-pointer transition-all border rounded-lg ${
                selectedEvent === event.id
                  ? "border-pink-500 ring-2 ring-pink-500 shadow-md"
                  : "border-gray-200 hover:border-pink-300"
              }`}
              onClick={() => handleEventSelect(event.id)}
            >
              <div className="p-6 flex items-center">
                <div className="text-4xl mr-4">{event.icon}</div>
                <div>
                  <h3 className="font-semibold text-lg text-pink-800">{event.name}</h3>
                  <p className="text-sm text-gray-500">{event.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-center">
          <button
            onClick={handleContinue}
            disabled={!selectedEvent || loading}
            className="bg-pink-600 hover:bg-pink-700 text-white rounded-full py-2 px-8 disabled:opacity-50"
          >
            {loading ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                Processing...
              </>
            ) : (
              "Get Recommendations"
            )}
          </button>
        </div>
      </div>
    </ProtectedLayout>
  )
}
