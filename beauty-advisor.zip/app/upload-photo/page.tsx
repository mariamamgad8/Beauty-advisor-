"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import ProtectedLayout from "@/components/protected-layout"
import { uploadProfilePhoto } from "@/services/user"
import { useAuth } from "@/contexts/auth-context"

export default function UploadPhoto() {
  const router = useRouter()
  const { user, setUser } = useAuth()
  const [loading, setLoading] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [error, setError] = useState("")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]

      // Check file type
      if (!selectedFile.type.startsWith("image/")) {
        setError("Please select an image file")
        return
      }

      // Check file size (max 5MB)
      if (selectedFile.size > 5 * 1024 * 1024) {
        setError("Image size should be less than 5MB")
        return
      }

      setFile(selectedFile)
      setError("")

      // Create preview
      const reader = new FileReader()
      reader.onload = () => {
        setPreview(reader.result as string)
      }
      reader.readAsDataURL(selectedFile)
    }
  }

  const handleUpload = async () => {
    if (!file || !user) return

    try {
      setLoading(true)

      // Upload photo to API
      const photo = await uploadProfilePhoto(file)

      // Update user in context with photo info
      setUser({
        ...user,
        avatarUrl: photo.publicUrl,
        hasUploadedPhoto: true,
      })

      // Redirect to event selection
      router.push("/select-event")
    } catch (err: any) {
      console.error("Error uploading photo:", err)
      setError(err.message || "Error uploading photo")
    } finally {
      setLoading(false)
    }
  }

  return (
    <ProtectedLayout>
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-pink-800">Upload Your Photo</h2>
            <p className="mt-2 text-gray-600">
              Please upload a clear, well-lit photo of your face to get the best recommendations
            </p>
          </div>

          {error && (
            <div className="mb-4 p-2 bg-red-50 border border-red-200 rounded text-red-600 text-sm">{error}</div>
          )}

          <div className="mb-6">
            <div
              className="border-2 border-dashed border-pink-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-pink-50 transition-colors"
              onClick={() => document.getElementById("photo-upload")?.click()}
            >
              {preview ? (
                <div className="relative w-48 h-48 mb-4">
                  <img
                    src={preview || "/placeholder.svg"}
                    alt="Preview"
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
              ) : (
                <div className="w-16 h-16 mb-4 bg-pink-100 rounded-full flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-pink-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    />
                  </svg>
                </div>
              )}

              <p className="text-sm text-gray-500 text-center">
                {preview ? "Click to change photo" : "Click to select a photo or drag and drop"}
              </p>
              <input id="photo-upload" type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            </div>
          </div>

          <div className="flex justify-center">
            <button
              onClick={handleUpload}
              disabled={!file || loading}
              className="bg-pink-600 hover:bg-pink-700 text-white rounded-full py-2 px-8 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Uploading...
                </>
              ) : (
                "Continue"
              )}
            </button>
          </div>

          <p className="mt-4 text-xs text-center text-gray-500">
            Your photo will only be used to generate personalized recommendations and will be stored securely.
          </p>
        </div>
      </div>
    </ProtectedLayout>
  )
}
