"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import ProtectedLayout from "@/components/protected-layout"
import { getRecommendation, submitFeedback } from "@/services/recommendations"
import type { Recommendation, FeedbackData } from "@/types"

export default function Recommendations() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const sessionId = searchParams.get("session")

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [activeTab, setActiveTab] = useState("makeup")
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null)
  const [feedback, setFeedback] = useState<{
    rating: "positive" | "negative" | null
    comment: string
  }>({
    rating: null,
    comment: "",
  })
  const [submittingFeedback, setSubmittingFeedback] = useState(false)

  useEffect(() => {
    // Fetch recommendation data
    async function fetchRecommendation() {
      if (!sessionId) {
        setError("No session ID provided")
        setLoading(false)
        return
      }

      try {
        setLoading(true)
        setError("")

        const data = await getRecommendation(sessionId)
        setRecommendation(data)
      } catch (err: any) {
        console.error("Error fetching recommendation:", err)
        setError(err.message || "Failed to load recommendation")
      } finally {
        setLoading(false)
      }
    }

    fetchRecommendation()
  }, [sessionId])

  const handleFeedbackRating = (rating: "positive" | "negative") => {
    setFeedback((prev) => ({ ...prev, rating }))
  }

  const handleFeedbackComment = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFeedback((prev) => ({ ...prev, comment: e.target.value }))
  }

  const handleSubmitFeedback = async () => {
    if (!feedback.rating || !sessionId) return

    try {
      setSubmittingFeedback(true)
      setError("")

      const feedbackData: FeedbackData = {
        sessionId,
        rating: feedback.rating,
        comment: feedback.comment || undefined,
      }

      await submitFeedback(feedbackData)

      // Show success message
      alert("Thank you for your feedback!")

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (err: any) {
      console.error("Error submitting feedback:", err)
      setError(err.message || "Failed to submit feedback")
    } finally {
      setSubmittingFeedback(false)
    }
  }

  return (
    <ProtectedLayout>
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-pink-800">Your Personalized Recommendations</h2>
          <p className="mt-2 text-gray-600">Based on your photo and selected event</p>
        </div>

        {error && <div className="mb-4 p-2 bg-red-50 border border-red-200 rounded text-red-600 text-sm">{error}</div>}

        {loading ? (
          <div className="flex flex-col items-center justify-center p-4">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-600 mb-4"></div>
            <h2 className="text-xl font-medium text-pink-800">Generating your personalized recommendations...</h2>
            <p className="text-gray-600 mt-2 text-center">
              Our AI is analyzing your photo and creating the perfect look for your event
            </p>
          </div>
        ) : recommendation ? (
          <>
            <div className="mb-8">
              <div className="flex border-b border-gray-200">
                <button
                  className={`py-2 px-4 font-medium ${
                    activeTab === "makeup"
                      ? "text-pink-600 border-b-2 border-pink-600"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                  onClick={() => setActiveTab("makeup")}
                >
                  Makeup Recommendations
                </button>
                <button
                  className={`py-2 px-4 font-medium ${
                    activeTab === "hair"
                      ? "text-pink-600 border-b-2 border-pink-600"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                  onClick={() => setActiveTab("hair")}
                >
                  Hairstyle Recommendations
                </button>
              </div>

              <div className="bg-white shadow-md rounded-lg mt-4">
                <div className="p-6">
                  {activeTab === "makeup" && (
                    <>
                      <h3 className="text-2xl font-bold text-pink-800 mb-2">{recommendation.makeup.title}</h3>
                      <p className="text-gray-600 mb-6">{recommendation.makeup.description}</p>

                      <div className="bg-pink-50 p-4 rounded-lg mb-6">
                        <h4 className="font-semibold text-pink-800 mb-2">Recommended Products & Techniques:</h4>
                        <ul className="space-y-2">
                          {recommendation.makeup.items.map((item, index) => (
                            <li key={index} className="flex items-start">
                              <span className="text-pink-500 mr-2">•</span>
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-purple-800 mb-2">Pro Tips:</h4>
                        <p className="text-gray-700">
                          For your skin tone and features, focus on blending well around the eyes and use a setting
                          spray to ensure your makeup lasts throughout the event.
                        </p>
                      </div>
                    </>
                  )}

                  {activeTab === "hair" && (
                    <>
                      <h3 className="text-2xl font-bold text-pink-800 mb-2">{recommendation.hair.title}</h3>
                      <p className="text-gray-600 mb-6">{recommendation.hair.description}</p>

                      <div className="bg-pink-50 p-4 rounded-lg mb-6">
                        <h4 className="font-semibold text-pink-800 mb-2">Recommended Styles:</h4>
                        <ul className="space-y-2">
                          {recommendation.hair.items.map((item, index) => (
                            <li key={index} className="flex items-start">
                              <span className="text-pink-500 mr-2">•</span>
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-purple-800 mb-2">Pro Tips:</h4>
                        <p className="text-gray-700">
                          For your hair texture and length, prep with a heat protectant before styling and finish with a
                          light-hold hairspray to maintain the look without stiffness.
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Feedback Section */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h3 className="text-xl font-bold text-pink-800 mb-4">How do you like these recommendations?</h3>

              <div className="flex space-x-4 mb-6">
                <button
                  className={`px-4 py-2 rounded-md flex items-center ${
                    feedback.rating === "positive"
                      ? "bg-green-600 text-white"
                      : "border border-gray-300 text-gray-700 hover:bg-gray-50"
                  }`}
                  onClick={() => handleFeedbackRating("positive")}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
                  </svg>
                  Love it!
                </button>

                <button
                  className={`px-4 py-2 rounded-md flex items-center ${
                    feedback.rating === "negative"
                      ? "bg-red-600 text-white"
                      : "border border-gray-300 text-gray-700 hover:bg-gray-50"
                  }`}
                  onClick={() => handleFeedbackRating("negative")}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 mr-2"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path d="M18 9.5a1.5 1.5 0 11-3 0v-6a1.5 1.5 0 013 0v6zM14 9.667v-5.43a2 2 0 00-1.105-1.79l-.05-.025A4 4 0 0011.055 2H5.64a2 2 0 00-1.962 1.608l-1.2 6A2 2 0 004.44 12H8v4a2 2 0 002 2 1 1 0 001-1v-.667a4 4 0 01.8-2.4l1.4-1.866a4 4 0 00.8-2.4z" />
                  </svg>
                  Not for me
                </button>
              </div>

              <div className="mb-6">
                <label htmlFor="feedback" className="block text-sm font-medium text-gray-700 mb-1">
                  Additional comments (optional)
                </label>
                <textarea
                  id="feedback"
                  placeholder="Tell us more about what you think..."
                  value={feedback.comment}
                  onChange={handleFeedbackComment}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500 min-h-[100px]"
                ></textarea>
              </div>

              <button
                onClick={handleSubmitFeedback}
                disabled={!feedback.rating || submittingFeedback}
                className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-md disabled:opacity-50"
              >
                {submittingFeedback ? (
                  <>
                    <svg
                      className="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Submitting...
                  </>
                ) : (
                  "Submit Feedback"
                )}
              </button>
            </div>

            <div className="text-center">
              <button
                onClick={() => router.push("/dashboard")}
                className="border border-pink-600 text-pink-600 hover:bg-pink-50 px-4 py-2 rounded-md"
              >
                Go to Dashboard
              </button>
            </div>
          </>
        ) : (
          <div className="bg-white p-6 rounded-lg shadow-md text-center">
            <p className="text-gray-600">No recommendation found. Please try again.</p>
            <button
              onClick={() => router.push("/select-event")}
              className="mt-4 bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded-md"
            >
              Create New Recommendation
            </button>
          </div>
        )}
      </div>
    </ProtectedLayout>
  )
}
