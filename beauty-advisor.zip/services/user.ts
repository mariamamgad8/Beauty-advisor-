import { fetchAPI, uploadFile } from "./api"
import type { User, Photo } from "@/types"

export async function updateProfile(data: Partial<User>): Promise<User> {
  return fetchAPI<User>("/users/profile", {
    method: "PUT",
    body: JSON.stringify(data),
  })
}

export async function uploadProfilePhoto(file: File): Promise<Photo> {
  return uploadFile("/users/photo", file)
}

export async function changePassword(currentPassword: string, newPassword: string): Promise<void> {
  return fetchAPI<void>("/users/change-password", {
    method: "POST",
    body: JSON.stringify({ currentPassword, newPassword }),
  })
}

export async function deleteAccount(): Promise<void> {
  return fetchAPI<void>("/users/account", {
    method: "DELETE",
  })
}
