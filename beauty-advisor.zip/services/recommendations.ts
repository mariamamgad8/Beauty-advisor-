import { fetchAPI } from "./api"
import type { RecommendationSession, Recommendation, EventType, Feedback, FeedbackData } from "@/types"

export async function createRecommendationSession(eventType: EventType): Promise<RecommendationSession> {
  return fetchAPI<RecommendationSession>("/recommendations/sessions", {
    method: "POST",
    body: JSON.stringify({ eventType }),
  })
}

export async function getRecommendation(sessionId: string): Promise<Recommendation> {
  return fetchAPI<Recommendation>(`/recommendations/${sessionId}`)
}

export async function getRecommendationHistory(): Promise<RecommendationSession[]> {
  return fetchAPI<RecommendationSession[]>("/recommendations/history")
}

export async function submitFeedback(data: FeedbackData): Promise<Feedback> {
  return fetchAPI<Feedback>("/recommendations/feedback", {
    method: "POST",
    body: JSON.stringify(data),
  })
}
