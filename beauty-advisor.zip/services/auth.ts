import { fetchAPI } from "./api"
import type { User, SignUpData, LoginData } from "@/types"

interface AuthResponse {
  user: User
  token: string
}

export async function signUp(data: SignUpData): Promise<AuthResponse> {
  return fetchAPI<AuthResponse>("/auth/signup", {
    method: "POST",
    body: JSON.stringify(data),
  })
}

export async function login(data: LoginData): Promise<AuthResponse> {
  return fetchAPI<AuthResponse>("/auth/login", {
    method: "POST",
    body: JSON.stringify(data),
  })
}

export async function logout(): Promise<void> {
  return fetchAPI<void>("/auth/logout", {
    method: "POST",
  })
}

export async function getCurrentUser(): Promise<User> {
  return fetchAPI<User>("/auth/me")
}

export function saveToken(token: string): void {
  localStorage.setItem("token", token)
}

export function getToken(): string | null {
  return localStorage.getItem("token")
}

export function removeToken(): void {
  localStorage.removeItem("token")
}
