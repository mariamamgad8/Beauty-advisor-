import Link from "next/link"
import type { ReactNode } from "react"

type LayoutProps = {
  children: ReactNode
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-purple-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex-shrink-0">
              <Link href="/" className="text-2xl font-bold text-pink-800">
                Beauty Advisor
              </Link>
            </div>
            <nav className="flex space-x-4">
              <Link href="/login" className="text-gray-600 hover:text-pink-800">
                Login
              </Link>
              <Link href="/signup" className="text-gray-600 hover:text-pink-800">
                Sign Up
              </Link>
            </nav>
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="bg-pink-800 text-white py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-bold">Beauty Advisor</h3>
            <p className="text-pink-200">Your personal style companion</p>
          </div>
          <div className="flex space-x-6">
            <a href="#" className="text-pink-200 hover:text-white">
              About
            </a>
            <a href="#" className="text-pink-200 hover:text-white">
              Privacy
            </a>
            <a href="#" className="text-pink-200 hover:text-white">
              Terms
            </a>
            <a href="#" className="text-pink-200 hover:text-white">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
