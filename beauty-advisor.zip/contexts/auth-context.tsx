"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { User } from "@/types"
import { getCurrentUser, getToken, removeToken, saveToken } from "@/services/auth"

interface AuthContextType {
  user: User | null
  loading: boolean
  error: string | null
  setUser: (user: User | null) => void
  setToken: (token: string) => void
  clearAuth: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function loadUser() {
      const token = getToken()
      if (!token) {
        setLoading(false)
        return
      }

      try {
        const userData = await getCurrentUser()
        setUser(userData)
      } catch (err) {
        console.error("Failed to load user:", err)
        setError("Session expired. Please login again.")
        removeToken()
      } finally {
        setLoading(false)
      }
    }

    loadUser()
  }, [])

  const setToken = (token: string) => {
    saveToken(token)
  }

  const clearAuth = () => {
    setUser(null)
    removeToken()
  }

  return (
    <AuthContext.Provider value={{ user, loading, error, setUser, setToken, clearAuth }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
